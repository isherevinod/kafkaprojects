package com.example.springcloudstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudStreamDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
